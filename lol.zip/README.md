# Thread Oracle

Thread Oracle is a Reddit Devvit moderation tool that watches active threads for signs of chaos. It tracks comment velocity, tone signals, and user patterns, then uses Gemini AI to generate a public prophecy for the community and a private moderation warning for mods.

The app creates a dedicated Oracle dashboard post for a watched thread. Moderators get the full risk dashboard, AI moderation warning, and quick action controls, while regular users only see the public prophecy, comment count, and chaos score.

## What It Does

- Monitors Reddit posts as new comments arrive.
- Scores thread chaos from velocity, conflict language, sarcasm, dogpile behavior, and flagged-user history.
- Calls Gemini AI for predictions when a thread becomes genuinely heated.
- Creates a mod dashboard with a risk badge, chaos score, signal stats, private mod warning, and public prophecy.
- Adds a pinned Oracle comment to the watched thread that links to the dashboard.

## Features

- **Velocity tracking**: watches bursts of recent comments to spot fast-moving threads.
- **Conflict scoring**: detects argumentative phrases and escalation markers.
- **Sarcasm scoring**: tracks sarcasm patterns that often show up before a thread derails.
- **Dogpile detection**: flags when a small group dominates the conversation.
- **Flagged user radar**: tracks repeat commenters through Redis and boosts risk when flagged users return.
- **Mod vs user view**: moderators see the full dashboard and mod warning; non-mods see only public-safe information.
- **Pinned Oracle comment**: when summoned, the app comments on the original thread with a link to the Oracle dashboard and pins it.
- **Gemini key rotation**: supports up to three Gemini API keys to reduce rate-limit interruptions.

## How To Use

1. Install Thread Oracle in your subreddit.
2. Open any post you want to monitor.
3. Open the mod menu and choose **Summon Thread Oracle**.
4. Thread Oracle creates an Oracle dashboard post.
5. A pinned mod comment appears on the original thread with a link to the dashboard.
6. Open the dashboard to watch the chaos score, prophecy, and moderator warning update over time.

## Settings

Configure these app settings in Reddit Developer Settings:

- `gemini_api_key`: primary Gemini API key.
- `gemini_api_key_2`: optional secondary Gemini API key.
- `gemini_api_key_3`: optional tertiary Gemini API key.

Thread Oracle sends thread context and chaos metrics to Gemini only when prediction generation is needed.

## Tech Stack

- **Devvit**: Reddit app platform and custom post UI.
- **Hono**: backend routing for menu actions, triggers, and API routes.
- **Vite**: build tooling.
- **TypeScript**: type-safe app logic.
- **Gemini AI**: prophecy and moderation-warning generation.
- **Redis**: per-post oracle state, cooldowns, flagged-user counters, and summon tracking.

## Development

Install dependencies:

```bash
npm install
```

Run type-checking:

```bash
npm run type-check
```

Start Devvit playtest:

```bash
npm run dev
```

Deploy:

```bash
npm run deploy
```
