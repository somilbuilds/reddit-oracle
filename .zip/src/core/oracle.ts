type OracleRedis = {
  get(key: string): Promise<string | undefined>;
  set(
    key: string,
    value: string,
    options?: {
      nx?: boolean;
      xx?: boolean;
      expiration?: Date;
    }
  ): Promise<string>;
};

type OracleSettings = {
  get<T = string>(name: string): Promise<T | undefined>;
};

type ModHistoryEntry = {
  username: string;
  removals: number;
  isBanned: boolean;
};

type VerdictHistoryEntry = {
  score: number;
  verdict: string;
  timestamp: number;
};

type OracleReddit = {
  getPostById(
    postId: string
  ): Promise<{ title: string } | undefined>;
  getModLog?(options: {
    subredditName: string;
    type: 'removecomment';
  }): { all(): Promise<unknown[]> };
  getModerationLog?(options: {
    subredditName: string;
    type: 'removecomment';
  }): { all(): Promise<unknown[]> };
  getBannedUsers(options: {
    subredditName: string;
    username?: string;
  }): { all(): Promise<unknown[]> };
};

const CONFLICT_KEYWORDS = [
  'actually',
  'wrong',
  'cope',
  'ratio',
  'skill issue',
  'you people',
  'typical',
  'lol no',
] as const;

const SARCASM_PATTERNS = [
  '/s',
  'sure jan',
  'oh totally',
  'clearly',
  'obviously',
  'suuure',
  'riiight',
  'wow so',
  'great logic',
  'genius',
  'big brain',
  'congratulations',
  'wow thanks',
  'oh wow',
  'totally not',
  'definitely not',
  'sure buddy',
  'k buddy',
  'cool story',
  'sure thing',
] as const;

const GEMINI_URL =
  'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

const CHAOS_THRESHOLD = 55;
const GEMINI_COOLDOWN_MS = 10 * 60 * 1000;
const FORCE_GEMINI_COOLDOWN_MS = 30 * 1000;
const VELOCITY_WINDOW_MS = 2 * 60 * 1000;
const VELOCITY_HIGH_COUNT = 5;

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type PostOracleState = {
  commentCount: number;
  timestamps: number[];
  conflictScore: number;
  sarcasmScore: number;
  commenters: string[];
  chaosScore: number;
  riskLevel: RiskLevel;
  modWarning: string;
  prophecy: string;
  updatedAt: number;
  postTitle?: string;
  recentCommentSnippets?: string[];
  verdict?: string;
  geminiTemperature?: number;
  geminiAggression?: number;
  geminiSarcasm?: number;
  commentsSinceGemini?: number;
  modHistory?: ModHistoryEntry[];
  verdictHistory?: VerdictHistoryEntry[];
  peakChaos?: number;
  threadAge?: number;
};

export type OracleDeps = {
  redis: OracleRedis;
  settings: OracleSettings;
  reddit?: OracleReddit;
  subredditName?: string | undefined;
};

function postKey(postId: string, field: string): string {
  return `oracle:post:${postId}:${field}`;
}

function countKeywordHits(
  text: string,
  keywords: readonly string[]
): number {
  const lower = text.toLowerCase();

  let hits = 0;

  for (const keyword of keywords) {
    if (lower.includes(keyword)) hits += 1;
  }

  return hits;
}

function countRecentComments(
  timestamps: number[],
  now: number
): number {
  const cutoff = now - VELOCITY_WINDOW_MS;

  return timestamps.filter((ts) => ts >= cutoff).length;
}

function detectDogpile(commenters: string[]): boolean {
  if (commenters.length < 4) return false;

  const counts = new Map<string, number>();

  for (const name of commenters) {
    counts.set(name, (counts.get(name) ?? 0) + 1);
  }

  const sorted = [...counts.values()].sort((a, b) => b - a);

  const topThree = sorted
    .slice(0, 3)
    .reduce((sum, n) => sum + n, 0);

  return topThree / commenters.length >= 0.6;
}

export function calculateChaosScore(state: {
  timestamps: number[];
  conflictScore: number;
  sarcasmScore: number;
  commenters: string[];
  flaggedUsers: string[];
  extras: {
    capsScore: number;
    angerPunct: number;
    dismissive: number;
    geminiTemp: number;
    geminiAgg: number;
  };
}): number {
  const now = Date.now();

  const recentCount = countRecentComments(
    state.timestamps,
    now
  );

  let score = 0;

  if (recentCount > VELOCITY_HIGH_COUNT) {
    score += 30;
  } else {
    score += Math.min(recentCount * 5, 25);
  }

  score += Math.min(state.conflictScore * 5, 25);

  score += Math.min(state.sarcasmScore * 4, 20);

  if (detectDogpile(state.commenters)) {
    score += 25;
  }

  if (state.flaggedUsers.length >= 3) {
    score += 20;
  } else if (state.flaggedUsers.length > 0) {
    score += 10;
  }

  score += Math.min(state.extras.capsScore, 10);
  score += Math.min(state.extras.angerPunct, 8);
  score += Math.min(state.extras.dismissive, 8);
  score += Math.min(state.extras.geminiTemp, 15);
  score += Math.min(state.extras.geminiAgg, 10);

  return Math.min(100, Math.round(score));
}

export function riskLevelFromChaos(
  chaosScore: number
): RiskLevel {
  if (chaosScore >= 80) return 'CRITICAL';

  if (chaosScore >= 60) return 'HIGH';

  if (chaosScore >= 40) return 'MEDIUM';

  return 'LOW';
}

export function suggestedActionForChaos(
  chaosScore: number
): string {
  if (chaosScore >= 80) {
    return 'Consider locking thread, mod intervention likely needed';
  }

  if (chaosScore >= 60) {
    return 'Enable slow mode, watch for brigading';
  }

  if (chaosScore >= 40) {
    return 'Monitor thread closely, consider slow mode';
  }

  return 'Thread is calm — no mod action needed yet';
}

export function modActionSuggestions(): string[] {
  return [
    'Enable Slow Mode',
    'Monitor Brigading',
    'Prepare Lock',
  ];
}

export function describeChaos(
  state: PostOracleState
): string {
  const recentCount = countRecentComments(
    state.timestamps,
    Date.now()
  );

  const parts: string[] = [];

  if (recentCount > VELOCITY_HIGH_COUNT) {
    parts.push('reply velocity is spiking');
  } else if (recentCount > 0) {
    parts.push('conversation is warming up');
  }

  if (state.conflictScore >= 6) {
    parts.push('arguments are entrenched and combative');
  } else if (state.conflictScore >= 3) {
    parts.push('tone is getting argumentative');
  }

  if (state.sarcasmScore >= 5) {
    parts.push('sarcasm is dripping from every reply');
  } else if (state.sarcasmScore >= 2) {
    parts.push('sarcasm and side-eye are showing up');
  }

  if (detectDogpile(state.commenters)) {
    parts.push(
      'a small cluster of users is circling the thread'
    );
  }

  if (!parts.length) {
    return 'The thread hums quietly; the storm has not yet formed.';
  }

  return parts.join('; ') + '.';
}

async function readJsonArray(
  redis: OracleRedis,
  key: string
): Promise<string[]> {
  const raw = await redis.get(key);

  if (!raw) return [];

  try {
    const parsed: unknown = JSON.parse(raw);

    return Array.isArray(parsed)
      ? parsed.filter(
          (v): v is string => typeof v === 'string'
        )
      : [];
  } catch {
    return [];
  }
}

async function readModHistory(
  redis: OracleRedis,
  key: string
): Promise<ModHistoryEntry[]> {
  const raw = await redis.get(key);

  if (!raw) return [];

  try {
    const parsed: unknown = JSON.parse(raw);

    return Array.isArray(parsed)
      ? parsed.filter(
          (entry): entry is ModHistoryEntry =>
            !!entry &&
            typeof entry === 'object' &&
            typeof (
              entry as ModHistoryEntry
            ).username === 'string' &&
            typeof (
              entry as ModHistoryEntry
            ).removals === 'number' &&
            typeof (
              entry as ModHistoryEntry
            ).isBanned === 'boolean'
        )
      : [];
  } catch {
    return [];
  }
}

async function readVerdictHistory(
  redis: OracleRedis,
  key: string
): Promise<VerdictHistoryEntry[]> {
  const raw = await redis.get(key);

  if (!raw) return [];

  try {
    const parsed: unknown = JSON.parse(raw);

    return Array.isArray(parsed)
      ? parsed.filter(
          (entry): entry is VerdictHistoryEntry =>
            !!entry &&
            typeof entry === 'object' &&
            typeof (
              entry as VerdictHistoryEntry
            ).score === 'number' &&
            typeof (
              entry as VerdictHistoryEntry
            ).verdict === 'string' &&
            typeof (
              entry as VerdictHistoryEntry
            ).timestamp === 'number'
        )
      : [];
  } catch {
    return [];
  }
}

async function readTimestamps(
  redis: OracleRedis,
  key: string
): Promise<number[]> {
  const raw = await redis.get(key);

  if (!raw) return [];

  try {
    const parsed: unknown = JSON.parse(raw);

    return Array.isArray(parsed)
      ? parsed.filter(
          (v): v is number => typeof v === 'number'
        )
      : [];
  } catch {
    return [];
  }
}

async function readFlaggedUsers(
  redis: OracleRedis,
  commenters: string[]
): Promise<string[]> {
  const flaggedUsers: string[] = [];

  for (const commenter of commenters) {
    const flagCount = Number(
      (await redis.get(`oracle:flagged:${commenter}`)) ?? 0
    );

    if (flagCount > 0) {
      flaggedUsers.push(commenter);
    }
  }

  return flaggedUsers;
}

export async function checkUserModHistory(
  reddit: OracleReddit | undefined,
  subredditName: string | undefined,
  username: string
): Promise<ModHistoryEntry> {
  if (!reddit || !subredditName) {
    return {
      username,
      removals: 0,
      isBanned: false,
    };
  }

  try {
    const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
    const modLog = reddit.getModLog
      ? reddit.getModLog({
          subredditName,
          type: 'removecomment',
        })
      : reddit.getModerationLog?.({
          subredditName,
          type: 'removecomment',
        });
    const actions = modLog ? await modLog.all() : [];
    const removals = actions.filter((action) => {
      const entry = action as {
        createdAt?: Date | string | number;
        target?: { author?: string };
      };
      const createdAt = entry.createdAt
        ? new Date(entry.createdAt).getTime()
        : 0;

      return (
        createdAt >= cutoff &&
        entry.target?.author?.toLowerCase() ===
          username.toLowerCase()
      );
    }).length;
    const bannedUsers = await reddit
      .getBannedUsers({
        subredditName,
        username,
      })
      .all();
    const isBanned = bannedUsers.some((user) => {
      const entry = user as {
        username?: string;
        name?: string;
      };
      const bannedName = entry.username ?? entry.name;

      return (
        bannedName?.toLowerCase() ===
        username.toLowerCase()
      );
    });

    return {
      username,
      removals,
      isBanned,
    };
  } catch (err) {
    console.error(
      '[Oracle] failed to check user mod history',
      username,
      err
    );

    return {
      username,
      removals: 0,
      isBanned: false,
    };
  }
}

async function fetchPostTitle(
  deps: OracleDeps,
  postId: string
): Promise<string | undefined> {
  try {
    const post = await deps.reddit?.getPostById(postId);

    return post?.title;
  } catch (err) {
    console.error(
      '[Oracle] failed to fetch post title',
      postId,
      err
    );

    return undefined;
  }
}

export async function loadPostOracleState(
  deps: OracleDeps,
  postId: string
): Promise<PostOracleState> {
  const { redis } = deps;

  const [
    commentCountRaw,
    timestamps,
    conflictScoreRaw,
    sarcasmScoreRaw,
    commenters,
    chaosScoreRaw,
    modWarning,
    prophecy,
    postTitle,
    recentCommentSnippets,
    verdict,
    geminiTemperatureRaw,
    geminiAggressionRaw,
    geminiSarcasmRaw,
    commentsSinceGeminiRaw,
    modHistory,
    verdictHistory,
    peakChaosRaw,
    threadAgeRaw,
    updatedAtRaw,
  ] = await Promise.all([
    redis.get(postKey(postId, 'commentCount')),
    readTimestamps(redis, postKey(postId, 'timestamps')),
    redis.get(postKey(postId, 'conflictScore')),
    redis.get(postKey(postId, 'sarcasmScore')),
    readJsonArray(redis, postKey(postId, 'commenters')),
    redis.get(postKey(postId, 'chaosScore')),
    redis.get(postKey(postId, 'modWarning')),
    redis.get(postKey(postId, 'prophecy')),
    redis.get(postKey(postId, 'postTitle')),
    readJsonArray(
      redis,
      postKey(postId, 'recentCommentSnippets')
    ),
    redis.get(postKey(postId, 'verdict')),
    redis.get(postKey(postId, 'geminiTemperature')),
    redis.get(postKey(postId, 'geminiAggression')),
    redis.get(postKey(postId, 'geminiSarcasm')),
    redis.get(postKey(postId, 'commentsSinceGemini')),
    readModHistory(redis, postKey(postId, 'modHistory')),
    readVerdictHistory(
      redis,
      postKey(postId, 'verdictHistory')
    ),
    redis.get(postKey(postId, 'peakChaos')),
    redis.get(postKey(postId, 'threadAge')),
    redis.get(postKey(postId, 'updatedAt')),
  ]);

  const chaosScore = Number(chaosScoreRaw ?? 0);

  const state: PostOracleState = {
    commentCount: Number(commentCountRaw ?? 0),
    timestamps,
    conflictScore: Number(conflictScoreRaw ?? 0),
    sarcasmScore: Number(sarcasmScoreRaw ?? 0),
    commenters,
    chaosScore,
    riskLevel: riskLevelFromChaos(chaosScore),
    modWarning: modWarning ?? '',
    prophecy:
      prophecy ??
      'The Oracle stirs from slumber… comment more and destiny shall unfold.',
    updatedAt: Number(updatedAtRaw ?? 0),
    recentCommentSnippets,
    geminiTemperature: Number(geminiTemperatureRaw ?? 0),
    geminiAggression: Number(geminiAggressionRaw ?? 0),
    geminiSarcasm: Number(geminiSarcasmRaw ?? 0),
    commentsSinceGemini: Number(commentsSinceGeminiRaw ?? 0),
    modHistory,
    verdictHistory,
    peakChaos: Number(peakChaosRaw ?? chaosScore),
    threadAge: Number(threadAgeRaw ?? 0),
  };

  if (postTitle) {
    state.postTitle = postTitle;
  }

  if (verdict) {
    state.verdict = verdict;
  }

  return state;
}

async function callGemini(
  apiKeys: string[],
  systemPrompt: string,
  userPrompt: string
): Promise<string | undefined> {
  const geminiHost = new URL(GEMINI_URL).hostname;

  for (let index = 0; index < apiKeys.length; index += 1) {
    const apiKey = apiKeys[index];

    console.log(
      '[Oracle][Gemini] Outbound fetch starting:',
      geminiHost,
      'keyIndex=',
      index + 1,
      'prompt:',
      systemPrompt.slice(0, 80)
    );

    let response: Response;

    try {
      response = await fetch(
        `${GEMINI_URL}?key=${apiKey}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `${systemPrompt}\n\n${userPrompt}`,
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: 0.9,
              maxOutputTokens: 800,
            },
          }),
        }
      );
    } catch (err) {
      console.error(
        '[Oracle][Gemini] Fetch failed before Gemini response:',
        err
      );

      throw err;
    }

    if (response.status === 429) {
      console.warn(
        '[Oracle][Gemini] Rate limited; rotating key',
        index + 1,
        'of',
        apiKeys.length
      );

      continue;
    }

    if (!response.ok) {
      const body = await response.text();

      console.error(
        '[Oracle][Gemini] HTTP error from Gemini:',
        response.status,
        response.statusText,
        body.slice(0, 500)
      );

      throw new Error(
        `Gemini API error ${response.status}: ${body}`
      );
    }

    console.log(
      '[Oracle][Gemini] Outbound fetch succeeded:',
      geminiHost,
      'status=',
      response.status,
      response.statusText
    );

    const json = await response.json();

    const content =
      json?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

    if (!content) {
      console.error(
        '[Oracle][Gemini] Empty or malformed Gemini response:',
        JSON.stringify(json).slice(0, 1000)
      );

      throw new Error('Gemini returned empty content');
    }

    console.log(
      '[Oracle][Gemini] Received completion length:',
      content.length
    );

    return content;
  }

  console.warn(
    '[Oracle][Gemini] All configured Gemini keys were rate limited'
  );

  return undefined;
}

async function callGeminiMicroAnalysis(
  deps: OracleDeps,
  postId: string,
  apiKeys: string[],
  snippets: string[]
): Promise<{
  temperature: number;
  aggression: number;
  sarcasm: number;
  verdict: string;
} | null> {
  const systemPrompt =
    'You are a sentiment analyzer. Analyze these Reddit comments and return ONLY valid JSON with no other text: {temperature: 0-10, aggression: 0-10, sarcasm: 0-10, verdict: calm|warming|heated|explosive}';
  const geminiHost = new URL(GEMINI_URL).hostname;
  const prompt = `${systemPrompt}\n\n${snippets
    .slice(-5)
    .map((snippet, index) => `${index + 1}. ${snippet}`)
    .join('\n')}`;
  const cooldownKey = `oracle:gemini:cooldown:${postId}`;
  const now = Date.now();
  const lastCall = await deps.redis.get(cooldownKey);

  if (
    lastCall &&
    now - Number(lastCall) < GEMINI_COOLDOWN_MS
  ) {
    return null;
  }

  for (let index = 0; index < apiKeys.length; index += 1) {
    const apiKey = apiKeys[index];

    try {
      const response = await fetch(
        `${GEMINI_URL}?key=${apiKey}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: prompt,
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: 0,
              maxOutputTokens: 60,
            },
          }),
        }
      );

      if (response.status === 429) {
        console.warn(
          '[Oracle][Gemini] Micro-analysis rate limited; rotating key',
          index + 1,
          'of',
          apiKeys.length
        );

        continue;
      }

      if (!response.ok) {
        console.error(
          '[Oracle][Gemini] Micro-analysis HTTP error:',
          response.status,
          response.statusText,
          (await response.text()).slice(0, 500)
        );

        return null;
      }

      const json = await response.json();
      const content =
        json?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

      if (!content) return null;

      const parsed: unknown = JSON.parse(content);

      if (
        !parsed ||
        typeof parsed !== 'object' ||
        !('temperature' in parsed) ||
        !('aggression' in parsed) ||
        !('sarcasm' in parsed) ||
        !('verdict' in parsed)
      ) {
        return null;
      }

      const result = parsed as {
        temperature: unknown;
        aggression: unknown;
        sarcasm: unknown;
        verdict: unknown;
      };

      if (
        typeof result.temperature !== 'number' ||
        typeof result.aggression !== 'number' ||
        typeof result.sarcasm !== 'number' ||
        typeof result.verdict !== 'string'
      ) {
        return null;
      }

      console.log(
        '[Oracle][Gemini] Micro-analysis succeeded:',
        geminiHost,
        result.verdict
      );

      await deps.redis.set(cooldownKey, String(Date.now()));

      return {
        temperature: result.temperature,
        aggression: result.aggression,
        sarcasm: result.sarcasm,
        verdict: result.verdict,
      };
    } catch (err) {
      console.error(
        '[Oracle][Gemini] Micro-analysis failed:',
        err
      );

      return null;
    }
  }

  return null;
}

async function getGeminiApiKeys(
  settings: OracleSettings
): Promise<string[]> {
  const keys = await Promise.all([
    settings.get<string>('gemini_api_key'),
    settings.get<string>('gemini_api_key_2'),
    settings.get<string>('gemini_api_key_3'),
  ]);

  return keys
    .map((key) => key?.trim() ?? '')
    .filter((key) => key.length > 0);
}

function geminiFallbackPredictions(): {
  modWarning: string;
  prophecy: string;
} {
  return {
    modWarning:
      'Oracle is resting between visions. Check back shortly.',

    prophecy:
      'The crystal ball cracked mid-vision. The Oracle remains uneasy.',
  };
}

async function generatePredictions(
  deps: OracleDeps,
  postId: string,
  chaosScore: number,
  state: PostOracleState,
  existingState: {
    modWarning: string;
    prophecy: string;
  },
  force: boolean
): Promise<{
  modWarning: string;
  prophecy: string;
}> {
  const cooldownKey = `oracle:gemini:cooldown:${postId}`;
  const now = Date.now();
  const cooldownMs = force
    ? FORCE_GEMINI_COOLDOWN_MS
    : GEMINI_COOLDOWN_MS;
  const cooldownFallback = {
    modWarning: existingState.modWarning,
    prophecy: existingState.prophecy,
  };
  const acquired = await deps.redis.set(
    cooldownKey,
    String(now),
    {
      nx: true,
      expiration: new Date(now + cooldownMs),
    }
  );

  if (acquired !== 'OK') {
    const lastCall = await deps.redis.get(cooldownKey);

    if (
      lastCall &&
      now - Number(lastCall) < cooldownMs
    ) {
      return cooldownFallback;
    }

    await deps.redis.set(
      cooldownKey,
      String(now),
      {
        expiration: new Date(now + cooldownMs),
      }
    );
  }

  const apiKeys = await getGeminiApiKeys(
    deps.settings
  );

  if (!apiKeys.length) {
    console.warn(
      '[Oracle][Gemini] gemini_api_key is not configured; skipping Gemini generation for post',
      postId
    );

    return {
      modWarning:
        'Gemini API key is not configured. Add it in app settings to enable AI warnings.',

      prophecy:
        'The Oracle squints into the void but forgot its Gemini API key.',
    };
  }

  const postTitle =
    state.postTitle ??
    (await fetchPostTitle(deps, postId));

  const contextSummary = [
    `Post ID: ${postId}`,
    `Post title: ${postTitle ?? 'unknown'}`,
    `Chaos score: ${chaosScore}/100`,
    `Risk: ${state.riskLevel}`,
    `Comments tracked: ${state.commentCount}`,
    `Conflict signal: ${state.conflictScore}`,
    `Sarcasm signal: ${state.sarcasmScore}`,
    `Recent commenters: ${
      state.commenters.slice(-8).join(', ') || 'none yet'
    }`,
    `Recent comment snippets:\n${
      state.recentCommentSnippets
        ?.slice(-5)
        .map((s, i) => `${i + 1}. "${s}"`)
        .join('\n') ?? 'none yet'
    }`,
  ].join('\n');

  try {
    console.log(
      '[Oracle][Gemini] Generating predictions for post',
      postId,
      'chaos=',
      chaosScore,
      'risk=',
      state.riskLevel
    );

    const [modWarning, prophecy] = await Promise.all([
      callGemini(
        apiKeys,
        "You are a Reddit moderator reviewing a thread. Write 2 sentences max about what conflict pattern is forming and what action to consider. Be direct and specific. No fluff. Example: 'Thread is dogpiling around AI topic with repeat conflict from same users. Consider slow mode before the next wave hits.' Max 50 words. Always finish your sentences. End every sentence with a period. Never end mid-word or mid-phrase. If you reach the token limit, finish your current sentence first.",
        `${contextSummary}\n\nWrite the mod warning for moderators.`
      ),

      callGemini(
        apiKeys,
        "You are a witty Reddit lurker who has seen every type of argument play out a thousand times. Based on the comment snippets and chaos signals, write exactly 2 short funny sentences predicting what is about to happen in this thread. Write like a Reddit comment - casual, dry, specific. Identify the TYPE of person or argument that is clearly forming. No dramatic language. No 'Oracle'. No 'mortals'. No fantasy speak. Good examples: - 'Someone is definitely about to paste a 6 paragraph response that nobody asked for. The top reply will just be lol.' - 'Three people are arguing the same point from different angles and none of them realize it yet.' - 'A guy who hasnt touched grass since 2019 is about to explain why the entire industry is wrong.' - 'This thread is 10 comments away from someone bringing up their 15 years of experience.' Max 40 words. Always finish your sentences. End every sentence with a period. Never end mid-word or mid-phrase. If you reach the token limit, finish your current sentence first.",
        `${contextSummary}\n\nWrite the public prophecy users will see.`
      ),
    ]);

    if (!modWarning || !prophecy) {
      return geminiFallbackPredictions();
    }

    console.log(
      '[Oracle][Gemini] Successfully generated predictions for post',
      postId
    );

    return {
      modWarning,
      prophecy,
    };
  } catch (err) {
    const message =
      err instanceof Error ? err.message : String(err);

    console.error(
      '[Oracle][Gemini] Failed to generate predictions for post',
      postId,
      message
    );

    return {
      modWarning: `Oracle could not reach Gemini: ${message}`,

      prophecy: geminiFallbackPredictions().prophecy,
    };
  }
}

export async function recordComment(
  deps: OracleDeps,
  postId: string,
  body: string,
  author: string
): Promise<PostOracleState> {
  const { redis } = deps;

  const now = Date.now();

  const existing = await loadPostOracleState(
    deps,
    postId
  );

  const timestamps = [
    ...existing.timestamps,
    now,
  ].slice(-5);

  const isNewCommenter =
    !existing.commenters.includes(author);
  const commenters = isNewCommenter
    ? [...existing.commenters, author].slice(-50)
    : existing.commenters;

  const recentCommentSnippets = [
    ...(await readJsonArray(
      redis,
      postKey(postId, 'recentCommentSnippets')
    )),
    body.trim().slice(0, 120),
  ].slice(-10);

  const conflictDelta = countKeywordHits(
    body,
    CONFLICT_KEYWORDS
  );

  const sarcasmDelta = countKeywordHits(
    body,
    SARCASM_PATTERNS
  );

  const conflictScore =
    existing.conflictScore + conflictDelta;

  let sarcasmScore =
    existing.sarcasmScore + sarcasmDelta;

  const commentCount =
    existing.commentCount + 1;

  const letters = body.match(/[a-z]/gi) ?? [];
  const uppercaseLetters = body.match(/[A-Z]/g) ?? [];
  const capsScore =
    letters.length > 0 &&
    uppercaseLetters.length / letters.length > 0.3
      ? 10
      : 0;
  const angerPunct =
    (body.match(/[!?]/g) ?? []).length >= 3 ? 8 : 0;
  const dismissive = body.trim().length < 15 ? 8 : 0;

  let commentsSinceGemini =
    (existing.commentsSinceGemini ?? 0) + 1;
  let geminiTemperature =
    existing.geminiTemperature ?? 0;
  let geminiAggression =
    existing.geminiAggression ?? 0;
  let geminiSarcasm = existing.geminiSarcasm ?? 0;
  let verdict = existing.verdict;
  let verdictHistory = existing.verdictHistory ?? [];
  let newVerdictForHistory: string | undefined;

  if (commentsSinceGemini % 10 === 0) {
    const apiKeys = await getGeminiApiKeys(
      deps.settings
    );
    const microAnalysis =
      apiKeys.length > 0
        ? await callGeminiMicroAnalysis(
            deps,
            postId,
            apiKeys,
            recentCommentSnippets.slice(-5)
          )
        : null;

    if (microAnalysis) {
      geminiTemperature = microAnalysis.temperature;
      geminiAggression = microAnalysis.aggression;
      geminiSarcasm = microAnalysis.sarcasm;
      if (geminiSarcasm > 5) sarcasmScore += 2;
      verdict = microAnalysis.verdict;
      newVerdictForHistory = microAnalysis.verdict;
      commentsSinceGemini = 0;
    }
  }

  let modHistory = existing.modHistory ?? [];
  let modHistoryBonus = 0;

  if (isNewCommenter) {
    const modHistoryEntry =
      await checkUserModHistory(
        deps.reddit,
        deps.subredditName,
        author
      );

    modHistory = [
      ...modHistory.filter(
        (entry) =>
          entry.username.toLowerCase() !==
          author.toLowerCase()
      ),
      modHistoryEntry,
    ].slice(-25);

    if (modHistoryEntry.removals >= 2) {
      modHistoryBonus += 15;
    }

    if (modHistoryEntry.isBanned) {
      modHistoryBonus += 20;
    }
  }

  const flaggedUsers = await readFlaggedUsers(
    redis,
    commenters
  );

  const chaosScore = Math.min(
    100,
    calculateChaosScore({
      timestamps,
      conflictScore,
      sarcasmScore,
      commenters,
      flaggedUsers,
      extras: {
        capsScore,
        angerPunct,
        dismissive,
        geminiTemp: geminiTemperature,
        geminiAgg: geminiAggression,
      },
    }) + modHistoryBonus
  );

  const peakChaos = Math.max(
    existing.peakChaos ?? 0,
    chaosScore
  );

  if (newVerdictForHistory) {
    verdictHistory = [
      ...verdictHistory,
      {
        score: chaosScore,
        verdict: newVerdictForHistory,
        timestamp: Date.now(),
      },
    ].slice(-10);
  }

  const riskLevel =
    riskLevelFromChaos(chaosScore);

  let modWarning = existing.modWarning;
  let prophecy = existing.prophecy;
  const postTitle =
    existing.postTitle ??
    (await fetchPostTitle(deps, postId));

  const draftState: PostOracleState = {
    commentCount,
    timestamps,
    conflictScore,
    sarcasmScore,
    commenters,
    chaosScore,
    riskLevel,
    modWarning,
    prophecy,
    updatedAt: now,
    recentCommentSnippets,
    geminiTemperature,
    geminiAggression,
    geminiSarcasm,
    commentsSinceGemini,
    modHistory,
    verdictHistory,
    peakChaos,
  };

  if (postTitle) {
    draftState.postTitle = postTitle;
  }

  if (verdict) {
    draftState.verdict = verdict;
  }

  if (chaosScore > CHAOS_THRESHOLD) {
    const generated =
      await generatePredictions(
        deps,
        postId,
        chaosScore,
        draftState,
        draftState,
        false
      );

    modWarning = generated.modWarning;
    prophecy = generated.prophecy;

    draftState.modWarning = modWarning;
    draftState.prophecy = prophecy;
  } else if (!prophecy) {
    draftState.prophecy =
      'The Oracle watches quietly. The thread has not yet angered the algorithmic fates.';
  }

  draftState.updatedAt = now;

  await Promise.all([
    redis.set(
      postKey(postId, 'commentCount'),
      String(commentCount)
    ),

    redis.set(
      postKey(postId, 'timestamps'),
      JSON.stringify(timestamps)
    ),

    redis.set(
      postKey(postId, 'conflictScore'),
      String(conflictScore)
    ),

    redis.set(
      postKey(postId, 'sarcasmScore'),
      String(sarcasmScore)
    ),

    redis.set(
      postKey(postId, 'commenters'),
      JSON.stringify(commenters)
    ),

    redis.set(
      postKey(postId, 'chaosScore'),
      String(chaosScore)
    ),

    redis.set(
      postKey(postId, 'riskLevel'),
      riskLevel
    ),

    redis.set(
      postKey(postId, 'modWarning'),
      draftState.modWarning
    ),

    redis.set(
      postKey(postId, 'prophecy'),
      draftState.prophecy
    ),

    redis.set(
      postKey(postId, 'recentCommentSnippets'),
      JSON.stringify(recentCommentSnippets)
    ),

    redis.set(
      postKey(postId, 'verdict'),
      draftState.verdict ?? ''
    ),

    redis.set(
      postKey(postId, 'geminiTemperature'),
      String(draftState.geminiTemperature ?? 0)
    ),

    redis.set(
      postKey(postId, 'geminiAggression'),
      String(draftState.geminiAggression ?? 0)
    ),

    redis.set(
      postKey(postId, 'geminiSarcasm'),
      String(draftState.geminiSarcasm ?? 0)
    ),

    redis.set(
      postKey(postId, 'commentsSinceGemini'),
      String(draftState.commentsSinceGemini ?? 0)
    ),

    redis.set(
      postKey(postId, 'modHistory'),
      JSON.stringify(draftState.modHistory ?? [])
    ),

    redis.set(
      postKey(postId, 'verdictHistory'),
      JSON.stringify(draftState.verdictHistory ?? [])
    ),

    redis.set(
      postKey(postId, 'peakChaos'),
      String(draftState.peakChaos ?? chaosScore)
    ),

    redis.set(
      postKey(postId, 'postTitle'),
      draftState.postTitle ?? ''
    ),

    redis.set(
      postKey(postId, 'updatedAt'),
      String(now)
    ),
  ]);

  return draftState;
}

export async function analyzePost(
  deps: OracleDeps,
  postId: string,
  forceAnalysis = false
): Promise<PostOracleState> {
  const state = await loadPostOracleState(
    deps,
    postId
  );

  const chaosScore =
    state.chaosScore ||
    calculateChaosScore({
      timestamps: state.timestamps,
      conflictScore: state.conflictScore,
      sarcasmScore: state.sarcasmScore,
      commenters: state.commenters,
      flaggedUsers: [],
      extras: {
        capsScore: 0,
        angerPunct: 0,
        dismissive: 0,
        geminiTemp: state.geminiTemperature ?? 0,
        geminiAgg: state.geminiAggression ?? 0,
      },
    });

  const riskLevel =
    riskLevelFromChaos(chaosScore);

  const now = Date.now();

  if (chaosScore > CHAOS_THRESHOLD || forceAnalysis) {
    const generated =
      await generatePredictions(
        deps,
        postId,
        chaosScore,
        {
          ...state,
          chaosScore,
          riskLevel,
        },
        state,
        forceAnalysis
      );

    state.modWarning = generated.modWarning;
    state.prophecy = generated.prophecy;
  }

  state.chaosScore = chaosScore;
  state.riskLevel = riskLevel;
  state.updatedAt = now;
  const postTitle =
    state.postTitle ??
    (await fetchPostTitle(deps, postId));

  if (postTitle) {
    state.postTitle = postTitle;
  }

  const { redis } = deps;

  await Promise.all([
    redis.set(
      postKey(postId, 'chaosScore'),
      String(chaosScore)
    ),

    redis.set(
      postKey(postId, 'riskLevel'),
      riskLevel
    ),

    redis.set(
      postKey(postId, 'modWarning'),
      state.modWarning
    ),

    redis.set(
      postKey(postId, 'prophecy'),
      state.prophecy
    ),

    redis.set(
      postKey(postId, 'postTitle'),
      state.postTitle ?? ''
    ),

    redis.set(
      postKey(postId, 'updatedAt'),
      String(now)
    ),
  ]);

  return state;
}

export function getTargetPostId(
  postData: Record<string, unknown> | undefined,
  fallbackPostId: string
): string {
  const target = postData?.targetPostId;

  return typeof target === 'string' &&
    target.trim()
    ? target.trim()
    : fallbackPostId;
}
