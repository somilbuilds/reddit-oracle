# Thread Oracle

Thread Oracle is a Reddit Devvit moderation tool that watches active threads for signs of chaos. It tracks comment velocity, tone signals, user history, and recent comment snippets, then uses Gemini AI to generate a public prophecy for the community and a private moderation warning for mods.

The app creates a dedicated Oracle dashboard post for a watched thread. Moderators get a full thread intelligence dashboard with risk, score, user radar, AI warning, and quick action controls. Regular users only see public-safe information: the watched thread title, chaos score, comment count, verdict when available, and public prophecy.

## What It Does

- Monitors Reddit posts as new comments arrive.
- Seeds the Oracle with the latest 25 existing comments when summoned, so the dashboard is useful immediately.
- Scores thread chaos from velocity, conflict language, sarcasm, caps, angry punctuation, dismissive short replies, dogpile behavior, mod history, and Gemini micro-analysis.
- Calls Gemini AI for public predictions, private mod warnings, and lightweight sentiment verdicts.
- Creates a mod dashboard with a risk badge, chaos score, verdict, signal stats, user radar, private mod warning, public prophecy, and action buttons.
- Adds a pinned Oracle comment to the watched thread that links to the dashboard.
- Recovers from stale summon markers when a previous Oracle dashboard post was removed.

## Features

- **Velocity tracking**: watches bursts of recent comments to spot fast-moving threads.
- **Conflict scoring**: detects argumentative phrases and escalation markers.
- **Sarcasm scoring**: tracks broader Reddit sarcasm patterns such as `sure jan`, `big brain`, `cool story`, and related phrases.
- **Local tone signals**: boosts chaos for excessive caps, repeated `!`/`?`, and dismissive short comments.
- **Dogpile detection**: flags when a small group dominates the conversation.
- **Gemini micro-analysis**: every 10 comments, when cooldown allows, analyzes recent snippets for temperature, aggression, sarcasm, and verdict (`calm`, `warming`, `heated`, `explosive`).
- **Shared Gemini cooldown**: micro-analysis and full prophecy generation share one 5-minute cooldown per post, so only one Gemini request path runs per watched post during the window.
- **Recent comment snippets**: stores the last 10 snippets and sends the latest 5 to Gemini for more specific predictions.
- **User radar**: checks new commenters against subreddit mod history, counts recent removed comments, checks banned status, and boosts risk for risky accounts.
- **Filtered radar display**: hides the bot account and clean users with no removals or ban status.
- **Peak chaos tracking**: keeps the highest chaos score reached by the thread.
- **Verdict history**: stores recent Gemini verdict snapshots for the thread.
- **Mod vs user view**: moderators see the full intelligence panel and mod warning; non-mods see only public-safe information.
- **Pinned Oracle comment**: when summoned, the app comments on the original thread with a link to the Oracle dashboard and pins it.
- **Dynamic dashboard title**: Oracle posts are titled `🔮 Oracle Watching: <original post title>`.
- **Duplicate summon prevention**: prevents duplicate dashboards while the previous Oracle post exists, but clears stale markers if that post was removed.
- **Gemini key rotation**: supports up to three Gemini API keys to reduce rate-limit interruptions.

## Dashboard

### Public View

Non-mod users see:

- Watched thread title.
- Risk badge and chaos score.
- Chaos bar.
- Verdict badge when available.
- Comment count and last updated time.
- Public prophecy.

Raw Reddit IDs such as `t3_` and `t1_` are not shown in the UI.

### Moderator View

Moderators see the public top section plus:

- **Thread Stats**: comments tracked, peak chaos, conflict signals, sarcasm signals, Gemini temperature, and Gemini aggression.
- **User Radar**: users with prior removals or ban status, excluding the app bot account.
- **Public Prophecy**: the user-facing prediction.
- **Mod Warning**: private moderation guidance, with noisy API errors replaced by a calm resting message.
- **Action buttons**:
  - `Consult Oracle`: forces a fresh full Gemini prediction, bypassing cooldown.
  - `Enable Slow Mode`: attempts to set `🔥 Heated Discussion` flair.
  - `Lock Thread`: locks the watched thread, not the Oracle dashboard post.

## How To Use

1. Install Thread Oracle in your subreddit.
2. Open any post you want to monitor.
3. Open the mod menu and choose **Summon Thread Oracle**.
4. Thread Oracle creates an Oracle dashboard post.
5. A pinned mod comment appears on the original thread with a link to the dashboard.
6. Thread Oracle seeds the dashboard with the latest 25 comments from the thread.
7. Open the dashboard to watch the chaos score, prophecy, user radar, and moderator warning update over time.

## Settings

Configure these app settings in Reddit Developer Settings:

- `gemini_api_key`: primary Gemini API key.
- `gemini_api_key_2`: optional secondary Gemini API key.
- `gemini_api_key_3`: optional tertiary Gemini API key.

Thread Oracle sends thread context, recent comment snippets, and chaos metrics to Gemini only when prediction or micro-analysis generation is needed. Gemini calls are rate-limited by a shared per-post cooldown.

## Tech Stack

- **Devvit**: Reddit app platform and custom post UI.
- **Hono**: backend routing for menu actions, triggers, and API routes.
- **Vite**: build tooling.
- **TypeScript**: type-safe app logic.
- **Gemini AI**: prophecy and moderation-warning generation.
- **Redis**: per-post oracle state, recent snippets, cooldowns, mod history, verdict history, peak chaos, flagged-user counters, and summon tracking.

## Development

Install dependencies:

```bash
npm install
```

Run type-checking:

```bash
npm run type-check
```

Start Devvit playtest:

```bash
npm run dev
```

Deploy:

```bash
npm run deploy
```
